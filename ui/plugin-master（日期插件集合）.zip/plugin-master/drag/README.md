# 拖拽插件

> 说明：本插件基于jquery 

> 本插件兼容到ie8，还有许多功能可以扩展，小伙伴们可以一起合作

[在线预览](https://zhouatie.github.io/plugin/drag/index.html)


***

* pElem 父元素的className 如 ".option"
* cElem 子元素(要拖拽的元素)的className 如 ".option-list"
* style1:被拖动的样式
* style2:被替换的样式


### 调用方式
`$.KF_drag("父元素","被拖动的元素","被拖动的样式","被替换元素的样式")`
