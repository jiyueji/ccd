# 前言
因为不太喜欢别人写的插件，有些时候只需要某个插件里面的某一个功能却需要引入整个庞大的插件，所以以后会持续添加自己写的插件。如有疏忽或错误，希望您及时指出，我会尽早修改😆。遇到几个开发者给我提需求，等我看到后已经好多天了。可加我微信 1114349984 提需求。上次开发插件还是18年￣□￣｜｜

## [命令行翻译插件](https://github.com/zhouatie/plugin/tree/master/translate)

## [原生js实现日期选择插件](https://github.com/zhouatie/plugin/tree/master/datepicker)

## [原生js实现拾色器插件](https://github.com/zhouatie/plugin/tree/master/colorpicker)

## [原生js实现移动端选择器插件](https://github.com/zhouatie/plugin/tree/master/pickerView)

## [原生js实现拖拽缩放预览图片插件](https://github.com/zhouatie/plugin/tree/master/previewImg)

## [原生js实现省市区三级联动插件](https://github.com/zhouatie/plugin/tree/master/address)

## [基于jquery的拖拽排序插件](https://github.com/zhouatie/plugin/tree/master/drag)
