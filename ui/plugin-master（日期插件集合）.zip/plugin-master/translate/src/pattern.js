const isZh = new RegExp("[\u4E00-\u9FA5]+");

module.exports = { isZh }